<?php
/**
 * Plugin Name: WebP Image Converter by Elga Cloud
 * Description: A plugin by ElgaCloud to convert images to WebP format.
 * Version: 1.0
 * Author: Elga Cloud
 * License: GPL2
 * Text Domain: webp-image-converter
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Enqueue Scripts and Styles
function iwc_enqueue_scripts() {
    wp_enqueue_style( 'iwc-style', plugin_dir_url( __FILE__ ) . 'style.css' );
    wp_enqueue_script( 'iwc-script', plugin_dir_url( __FILE__ ) . 'script.js', array( 'jquery' ), null, true );
}
add_action( 'wp_enqueue_scripts', 'iwc_enqueue_scripts' );

// Shortcode to Display Image Upload Form
function iwc_image_converter_shortcode() {
    ob_start();
    ?>
    <div class="iwc-layout">
        <h1>Convert image to webp format</h1>
        <div>
            <input type="file" id="iwc-file-input" multiple accept="image/*">
        </div>
        <div id="iwc-previews"></div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode( 'elgacloud_image_webp_converter', 'iwc_image_converter_shortcode' );

// Add Admin Menu
function iwc_add_admin_menu() {
    add_menu_page(
        'WebP Image Converter by Elga Cloud',  // Page title
        'WebP Image Converter',              // Menu title
        'manage_options',                    // Capability
        'image_webp_converter',              // Menu slug
        'iwc_settings_page'                  // Callback function
    );
}
add_action( 'admin_menu', 'iwc_add_admin_menu' );

// Admin Page Callback Function
function iwc_settings_page() {
    ?>
    <div class="wrap">
        <h1>WebP Image Converter by Elga Cloud</h1>
        <p>Use the shortcode below to display the image conversion tool on any page or post:</p>
        <textarea readonly style="width: 100%; height: 100px;">[elgacloud_image_webp_converter]</textarea>
        <p>Simply copy and paste the shortcode into your content where you want the image upload interface to appear.</p>
        <p>For more information about our services, visit <a href="https://elgacloud.com/" target="_blank">Elga Cloud</a>.</p>
    </div>
    <?php
}
