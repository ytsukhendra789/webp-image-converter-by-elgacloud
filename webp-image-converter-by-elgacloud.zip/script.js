//<![CDATA[
jQuery(document).ready(function($) {
    let refs = {}; 
    refs.imagePreviews = $('#iwc-previews'); 
    refs.fileSelector = $('#iwc-file-input'); 

    function addImageBox(container) { 
        let imageBox = $('<div></div>'); 
        container.append(imageBox); 
        return imageBox; 
    } 

    function processFile(file) { 
        if (!file) { return; } 
        let imageBox = addImageBox(refs.imagePreviews); 

        new Promise(function (resolve, reject) { 
            let rawImage = new Image(); 
            rawImage.onload = function () { resolve(rawImage); }; 
            rawImage.onerror = function () { reject('Image failed to load'); }; 
            rawImage.src = URL.createObjectURL(file); 
        }) 
        .then(function (rawImage) { 
            return new Promise(function (resolve, reject) { 
                let canvas = document.createElement('canvas'); 
                let ctx = canvas.getContext("2d"); 
                canvas.width = rawImage.width; 
                canvas.height = rawImage.height; 
                ctx.drawImage(rawImage, 0, 0); 
                canvas.toBlob(function (blob) { 
                    if (blob) {
                        resolve(URL.createObjectURL(blob)); 
                    } else {
                        reject('Blob creation failed'); 
                    }
                }, "image/webp"); 
            }); 
        }) 
        .then(function (imageURL) { 
            return new Promise(function (resolve, reject) { 
                let scaledImg = new Image(); 
                scaledImg.onload = function () { 
                    resolve({ imageURL, scaledImg }); 
                }; 
                scaledImg.onerror = function () { reject('Image failed to load'); }; 
                scaledImg.src = imageURL; 
            }); 
        }) 
        .then(function (data) { 
            let imageLink = $('<a></a>'); 
            imageLink.attr('href', data.imageURL); 
            imageLink.attr('download', `${file.name}.webp`); 
            imageLink.append(data.scaledImg); 
            imageBox.empty(); 
            imageBox.append(imageLink); 
        }) 
        .catch(function (error) {
            console.error('Error processing file:', error);
        });
    } 

    function processFiles(files) { 
        for (let i = 0; i < files.length; i++) { 
            processFile(files[i]); 
        } 
    } 

    refs.fileSelector.on('change', function() { 
        processFiles(this.files); 
        this.value = ""; 
    }); 
});
//]]>
